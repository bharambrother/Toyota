=== NextGEN Gallery add-on for Fancy Gallery ===

Simply drop that folder into the wp-content/plugins/radykal-fancy-gallery/addons folder. If there is no addons folder, just create one.

